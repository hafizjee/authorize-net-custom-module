<?php
namespace MS\AuthorizeNet\Controller\Webhook;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\OrderFactory;
use Psr\Log\LoggerInterface;

class Authorize extends Action
{
    protected $orderFactory;
    protected $logger;

    public function __construct(
        Context $context,
        OrderFactory $orderFactory,
        LoggerInterface $logger
    ) {
        parent::__construct($context);
        $this->orderFactory = $orderFactory;
        $this->logger = $logger;
    }

    public function execute()
    {
      // Logger setup
      $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/custom_authorize_net.log');
      $logger = new \Zend_Log();
      $logger->addWriter($writer);

      $logger->info('Authorize controller is accessed.');
        $input = file_get_contents('php://input');
        $eventData = json_decode($input, true);

        $logger->info('Authorize.net Webhook received', ['data' => $eventData]);

        if (isset($eventData['eventType'])) {
            switch ($eventData['eventType']) {
                case 'net.authorize.payment.authcapture.created':
                    $status = Order::STATE_PROCESSING;
                    break;
                case 'net.authorize.payment.refund.created':
                    $status = Order::STATE_CLOSED;
                    break;
                // Add more cases as needed
                default:
                    $status = null; // Default status or handle unknown event type
            }

            if (isset($status) && isset($eventData['payload']['id'])) {
                $transactionId = $eventData['payload']['id'];

                // Assuming the order increment ID is stored in transaction ID for simplicity
                $order = $this->orderFactory->create()->loadByIncrementId($transactionId);

                if ($order->getId()) {
                    $order->setStatus($status);
                    $order->save();

                    $logger->info('Order status updated to ' . $status . ' for order ID: ' . $order->getId());
                } else {
                    $logger->error('Order not found for transaction ID: ' . $transactionId);
                }
            }
        }

        $this->getResponse()->setHttpResponseCode(200);
    }
}
