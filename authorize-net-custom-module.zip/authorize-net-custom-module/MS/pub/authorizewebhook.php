<?php
// Define the path to the log file
$logFile = __DIR__ . '/../var/log/custom_authorize_net.log';

// Read the raw input from the request
$input = file_get_contents('php://input');

// Decode the JSON payload
$eventData = json_decode($input, true);

// Prepare log data
$logData = [
    'timestamp' => date('Y-m-d H:i:s'),
    'raw_input' => $input,
    'decoded_data' => $eventData
];

// Ensure the log directory exists
if (!is_dir(dirname($logFile))) {
    mkdir(dirname($logFile), 0755, true);
}

// Write initial log data to the log file
file_put_contents($logFile, "Initial log data: " . print_r($logData, true), FILE_APPEND);

// Load Magento framework
use Magento\Framework\App\Bootstrap;
require __DIR__ . '/../app/bootstrap.php';

$params = $_SERVER;
$bootstrap = Bootstrap::create(BP, $params);
$obj = $bootstrap->getObjectManager();
$state = $obj->get('Magento\Framework\App\State');
$state->setAreaCode('frontend');

//Get the transaction ID from the decoded JSON
$trans_id = isset($eventData['payload']['id']) ? $eventData['payload']['id'] : null;

if ($trans_id) {
    try {
        // Log the transaction ID
        file_put_contents($logFile, "Processing transaction with ID: " . $trans_id . "\n", FILE_APPEND);

        // Get transaction details from Authorize.net
        $transactionDetails = getTransactionDetails($trans_id);
        file_put_contents($logFile, "Fetched transaction details: " . print_r($transactionDetails, true) . "\n", FILE_APPEND);

//        if ($transactionDetails['messages']['resultCode'] == 'Ok') {
          if ($transactionDetails['transaction']['responseCode'] == '1') {

            $invoiceNumber = $transactionDetails['transaction']['order']['invoiceNumber'];
            file_put_contents($logFile, "Invoice number found: " . $invoiceNumber . "\n", FILE_APPEND);

            // Load the order using the invoice number
           $order = $obj->get(\Magento\Sales\Api\Data\OrderInterface::class)->loadByIncrementId($invoiceNumber);

           // Extract payment details from the transaction details
           $cardNumber = $transactionDetails['transaction']['payment']['creditCard']['cardNumber'];
           $expirationDate = $transactionDetails['transaction']['payment']['creditCard']['expirationDate'];
           $cardType = $transactionDetails['transaction']['payment']['creditCard']['cardType'];
           file_put_contents($logFile, "Extracted Payment Details - Card Number: $cardNumber, Expiration Date: $expirationDate, Card Type: $cardType\n", FILE_APPEND);

                       // Prepare the payment information array
            $payment_trans_array = [
                'cardNumber' => $cardNumber,        // Masked card number
                'expirationDate' => $expirationDate, // Masked expiration date
                'cardType' => $cardType,             // Card type
                'transactionId' => $trans_id // transaction Id
            ];

// Import the additional payment information
// Set the additional payment information
$payment = $order->getPayment();
$payment->setAdditionalInformation($payment_trans_array);
$order->save();

            if ($order->canInvoice()) {
                // Create invoice
                $invoiceService = $obj->get('Magento\Sales\Model\Service\InvoiceService');
                $transaction = $obj->get('Magento\Framework\DB\Transaction');
		$invoiceSender = $obj->get('Magento\Sales\Model\Order\Email\Sender\InvoiceSender');
                $invoice = $invoiceService->prepareInvoice($order);

                if (!$invoice) {
                    throw new Exception('Cannot create an invoice.');
                }

                $invoice->register();
                $invoice->pay();
                $invoice->save();
                file_put_contents($logFile, 'Invoice created for order ID ' . $order->getId() . "\n", FILE_APPEND);

                $transaction->addObject($invoice)
                    ->addObject($invoice->getOrder())
                    ->save();
			//Send Invoice mail to customer
                $invoiceSender->send($invoice);
                $order->addStatusToHistory($order->getStatus(), 'Transaction' . $trans_id)
                                                 ->setIsCustomerNotified(true)->save();

                // Set the transaction ID and update order status
	$order->setState(\Magento\Sales\Model\Order::STATE_PROCESSING, true)->save();
        $order->setStatus(\Magento\Sales\Model\Order::STATE_PROCESSING, true)->save();
        $order->addStatusToHistory($order->getStatus(), 'Order processed successfully');
        $order->save();
                file_put_contents($logFile, 'Order status updated to processing for order ID ' . $order->getId() . "\n", FILE_APPEND);

                echo 'Transaction completed successfully.';
            } else {
                throw new Exception('Order cannot be invoiced.');
            }
        } else {
            throw new Exception('Error getting transaction details: ' . $transactionDetails['messages']['message'][0]['text']);
        }
    } catch (Exception $e) {
        file_put_contents($logFile, 'Error processing transaction: ' . $e->getMessage() . "\n", FILE_APPEND);
        echo 'Error: ' . $e->getMessage();
    }
} else {
    echo 'Invalid transaction ID.';
}

function getTransactionDetails($transactionId) {
    $merchantAuthentication = [
        "name" => "test",
        "transactionKey" => "test"
    ];

    $data = [
        "getTransactionDetailsRequest" => [
            "merchantAuthentication" => $merchantAuthentication,
            "transId" => $transactionId
        ]
    ];

    $apiUrl = "https://api.authorize.net/xml/v1/request.api";
    $options = [
        'http' => [
            'header'  => "Content-type: application/json\r\n",
            'method'  => 'POST',
            'content' => json_encode($data),
        ],
    ];

    $context  = stream_context_create($options);
    $response = file_get_contents($apiUrl, false, $context);

    if ($response === FALSE) {
        throw new Exception('Error connecting to Authorize.net');
    }

    $cleanResponse = preg_replace("/^" . pack('H*','EFBBBF') . "/", '', $response);
    $responseData = json_decode($cleanResponse, true);

    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('Error decoding JSON response: ' . json_last_error_msg());
    }

    return $responseData;
}
?>
