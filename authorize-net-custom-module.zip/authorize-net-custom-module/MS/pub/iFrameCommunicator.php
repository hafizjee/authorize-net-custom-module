<?php

ini_set('display_errors', 1);
error_reporting(E_ALL);
use Magento\Framework\App\Bootstrap;
require __DIR__ . '/../app/bootstrap.php';
use Magento\Framework\App\Filesystem\DirectoryList;

$params = $_SERVER;
$bootstrap = Bootstrap::create(BP, $params);
$obj = $bootstrap->getObjectManager();
$state = $obj->get('Magento\Framework\App\State');
$state->setAreaCode('frontend');

// Logger setup
$writer = new \Zend_Log_Writer_Stream(BP . '/var/log/authorize_net.log');
$logger = new \Zend_Log();
$logger->addWriter($writer);
$logger->info('newyorkcables');

// Get the order ID from the URL parameter
$order_id = isset($_GET['order_id']) ? (int)$_GET['order_id'] : null;

if ($order_id) {
    try {
        // Load the order
        $orderRepository = $obj->get('Magento\Sales\Model\OrderRepository');
        $order = $orderRepository->get($order_id);
        // Check if the order is already paid
          if ($order->hasInvoices() || $order->getStatus() == 'canceled') {
              echo 'Sorry! This link has expired as the payment has already been received or the order has been canceled.';
        } else {

        // Generate the Authorize.net token
        $amount = $order->getGrandTotal();
        $billingAddress = $order->getBillingAddress();
        $shippingAddress = $order->getShippingAddress();
        $customerEmail = $order->getCustomerEmail();
        $incrementId = $order->getIncrementId();
        // Prepare line items
$lineItems = [];
foreach ($order->getAllVisibleItems() as $item) {
  $itemName = $item->getName();
$limitedItemName = substr($itemName, 0, 25); // Limit the name to 25 characters

    $lineItems[] = [
        'itemId' => $item->getSku(),
        'name' => $limitedItemName,
        'quantity' => (string)$item->getQtyOrdered(),
        'unitPrice' => number_format($item->getPrice(), 2, '.', '')
    ];
}

        $data = [
            "getHostedPaymentPageRequest" => [
                "merchantAuthentication" => [
                    "name" => "test",
                    "transactionKey" => "test"
                ],
                "transactionRequest" => [
                    "transactionType" => "authCaptureTransaction",
                    "amount" => number_format($amount, 2, '.', ''),
                    "order" => [
                    "invoiceNumber"=> $incrementId,
		    "description" =>"Goods or Services"
                  ],
                  "lineItems" => [
                  "lineItem" => $lineItems
                  ],
                    "customer" => [
                        "email" => $customerEmail
                    ],
                    "billTo" => [
                        "firstName" => $billingAddress->getFirstname(),
                        "lastName" => $billingAddress->getLastname(),
                        "company" => $billingAddress->getCompany(),
                        "address" => $billingAddress->getStreetLine(1),
                        "city" => $billingAddress->getCity(),
                        "state" => $billingAddress->getRegion(),
                        "zip" => $billingAddress->getPostcode(),
                        "country" => $billingAddress->getCountryId()
                    ],

 	            "shipTo" => [
                        "firstName" => $shippingAddress->getFirstname(),
                        "lastName" => $shippingAddress->getLastname(),
                        "company" => $shippingAddress->getCompany(),
                        "address" => $shippingAddress->getStreetLine(1),
                        "city" => $shippingAddress->getCity(),
                        "state" => $shippingAddress->getRegion(),
                        "zip" => $shippingAddress->getPostcode(),
                        "country" => $shippingAddress->getCountryId()
                    ]
],
                "hostedPaymentSettings" => [
                    "setting" => [
                        [
                            "settingName" => "hostedPaymentReturnOptions",
                            "settingValue" => json_encode([
                                "showReceipt" => true,
                                "url" => "https://www.test.com/",
                                "urlText" => "Continue",
                                "cancelUrl" => "https://www.test.com/",
                                "cancelUrlText" => "Continue Shopping"
                            ])
                        ],
                        [
                            "settingName" => "hostedPaymentButtonOptions",
                            "settingValue" => json_encode([
                                "text" => "Pay"
                            ])
                        ],
                        [
                            "settingName" => "hostedPaymentStyleOptions",
                            "settingValue" => json_encode([
                                "bgColor" => "blue"
                            ])
                        ],
                        [
                            "settingName" => "hostedPaymentPaymentOptions",
                            "settingValue" => json_encode([
                                "cardCodeRequired" => false,
                                "showCreditCard" => true,
                                "showBankAccount" => false
                            ])
                        ],
                        [
                            "settingName" => "hostedPaymentSecurityOptions",
                            "settingValue" => json_encode([
                                "captcha" => false
                            ])
                        ],
                        [
                            "settingName" => "hostedPaymentShippingAddressOptions",
                            "settingValue" => json_encode([
                                "show" => false,
                                "required" => false
                            ])
                        ],
                        [
                            "settingName" => "hostedPaymentBillingAddressOptions",
                            "settingValue" => json_encode([
                                "show" => false,
                                "required" => false
                            ])
                        ],
                        [
                            "settingName" => "hostedPaymentCustomerOptions",
                            "settingValue" => json_encode([
                                "showEmail" => false,
                                "requiredEmail" => false,
                                "addPaymentProfile" => true
                            ])
                        ],
                        [
                            "settingName" => "hostedPaymentOrderOptions",
                            "settingValue" => json_encode([
                                "show" => true,
                                "merchantName" => "NewYork Cables"
                            ])
                        ],
                        [
                            "settingName" => "hostedPaymentIFrameCommunicatorUrl",
                            "settingValue" => json_encode([
                                "url" => "https://www.test.com/iFrameCommunicator.php"
                            ])
                        ]
                    ]
                ]
                            ]
];

        $apiUrl = "https://api.authorize.net/xml/v1/request.api";
        $options = [
            'http' => [
                'header'  => "Content-type: application/json\r\n",
                'method'  => 'POST',
                'content' => json_encode($data),
            ],
        ];

        $context  = stream_context_create($options);
        $response = file_get_contents($apiUrl, false, $context);

        if ($response === FALSE) {
            throw new Exception('Error connecting to Authorize.net');
        }

        $cleanResponse = preg_replace("/^" . pack('H*','EFBBBF') . "/", '', $response);
        $responseData = json_decode($cleanResponse, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception('Error decoding JSON response: ' . json_last_error_msg());
        }

        if (isset($responseData['messages']['resultCode']) && $responseData['messages']['resultCode'] == 'Ok') {
            $token = $responseData['token'];

            // Log the token for debugging purposes
            $logger->info('Generated token: ' . $token);
            ?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.min.js"></script>
    <title>HostedPayment Test Page</title>
    <style type="text/css">
        body {
            margin: 0px;
            padding: 0px;
        }

        #divAuthorizeNetPopupScreen {
            left: 0px;
            top: 0px;
            width: 100%;
            height: 100%;
            z-index: 1;
            background-color: #808080;
            opacity: 0.5;
            -ms-filter: 'progid:DXImageTransform.Microsoft.Alpha(Opacity=50)';
            filter: alpha(opacity=50);
        }

        #divAuthorizeNetPopup {
            position: absolute;
            left: 50%;
            top: 50%;
            margin-left: -200px;
            margin-top: -200px;
            z-index: 2;
            overflow: visible;
        }

        .AuthorizeNetPopupGrayFrameTheme .AuthorizeNetPopupOuter {
            background-color: #dddddd;
            border-width: 1px;
            border-style: solid;
            border-color: #a0a0a0 #909090 #909090 #a0a0a0;
            padding: 4px;
        }

        .AuthorizeNetPopupGrayFrameTheme .AuthorizeNetPopupTop {
            height: 23px;
        }

        .AuthorizeNetPopupGrayFrameTheme .AuthorizeNetPopupClose {
            position: absolute;
            right: 7px;
            top: 7px;
        }

        .AuthorizeNetPopupGrayFrameTheme .AuthorizeNetPopupClose a {
            background-image: url('content/closeButton1.png');
            background-repeat: no-repeat;
            height: 16px;
            width: 16px;
            display: inline-block;
        }

        .AuthorizeNetPopupGrayFrameTheme .AuthorizeNetPopupClose a:hover {
            background-image: url('content/closeButton1h.png');
        }

        .AuthorizeNetPopupGrayFrameTheme .AuthorizeNetPopupClose a:active {
            background-image: url('content/closeButton1a.png');
        }

        .AuthorizeNetPopupGrayFrameTheme .AuthorizeNetPopupInner {
            background-color: #ffffff;
            border-width: 2px;
            border-style: solid;
            border-color: #cfcfcf #ebebeb #ebebeb #cfcfcf;
        }

        .AuthorizeNetPopupGrayFrameTheme .AuthorizeNetPopupBottom {
            height: 30px;
        }

        .AuthorizeNetPopupGrayFrameTheme .AuthorizeNetPopupLogo {
            position: absolute;
            right: 9px;
            bottom: 4px;
            width: 200px;
            height: 25px;
            background-image: url('content/powered_simple.png');
        }

        .AuthorizeNetPopupSimpleTheme .AuthorizeNetPopupOuter {
            border: 1px solid #585858;
            background-color: #ffffff;
        }
    </style>
</head>

<body>
    <form method="post" action= "https://accept.authorize.net/payment/payment" id="formAuthorizeNetPopup">
        <input type="hidden" name="token" id="popupToken" value="<?php echo $token; ?>" />
        <input type="submit" id="btnSubmit" value="Submit" style="display:none;" />
    </form>

    <div id="divAuthorizeNetPopupScreen" style="display:none;"></div>
    <div id="divAuthorizeNetPopup" class="AuthorizeNetPopupGrayFrameTheme" style="display:none;">
        <div class="AuthorizeNetPopupOuter">
            <div class="AuthorizeNetPopupTop">
                <div class="AuthorizeNetPopupClose">
                    <a href="javascript:void(0);" onclick="OnPopupClose();"></a>
                </div>
            </div>
            <div class="AuthorizeNetPopupInner">
                <iframe name="iframeAuthorizeNetPopup" id="iframeAuthorizeNetPopup" width="100%" height="600px"
                    scrolling="no" frameborder="0" marginheight="0" marginwidth="0" title="Payment Form">
                    <p>Browser unable to load iFrame</p>
                </iframe>
            </div>
            <div class="AuthorizeNetPopupBottom">
                <div class="AuthorizeNetPopupLogo"></div>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        window.onload = OnLoadAuthorizeNetPopup;

        function OnLoadAuthorizeNetPopup() {
            // Log token value for debugging
            console.log("Token value: " + document.getElementById('popupToken').value);

            document.getElementById("divAuthorizeNetPopupScreen").style.display = "block";
            document.getElementById("divAuthorizeNetPopup").style.display = "block";
            document.getElementById("btnSubmit").click();
            document.getElementById("iframeAuthorizeNetPopup").src = document.getElementById("formAuthorizeNetPopup").action;
        }

        function OnPopupClose() {
            document.getElementById("divAuthorizeNetPopupScreen").style.display = "none";
            document.getElementById("divAuthorizeNetPopup").style.display = "none";
        }
    </script>
</body>
</html>
            <?php
        } else {
            throw new Exception('Error generating token: ' . $responseData['messages']['message'][0]['text']);
        }
}
    } catch (Exception $e) {
        // Log the error
        $logger->err($e->getMessage());
        echo 'Error: ' . $e->getMessage();
    }
} else {
    echo 'Invalid order ID';
}
?>
