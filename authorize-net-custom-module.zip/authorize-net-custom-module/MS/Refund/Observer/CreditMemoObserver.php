<?php
namespace MS\Refund\Observer;
use Magento\Framework\Event\ObserverInterface;

class CreditMemoObserver implements ObserverInterface
{
    // Logger and merchant authentication properties
    public $logger;
    public $merchantAuthentication;

    public function __construct()
    {
        // Set up the logger
        $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/refund_details.log');
        $this->logger = new \Zend_Log();
        $this->logger->addWriter($writer);

        // Define merchant authentication details
        $this->merchantAuthentication = [
            "name" => "test",
            "transactionKey" => "test"
        ];

    }
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
      if ($observer->getEvent()->getCreditmemo()->getOrder()->getPayment()->getMethodInstance()->getCode() == "customauthorizenet") {
        $this->logger->info("Credit Memo Event Triggered");
        $additionalInformation = $observer->getEvent()->getCreditmemo()
                                          ->getOrder()->getPayment()->getAdditionalInformation();
        $amount = $observer->getEvent()->getCreditmemo()->getOrder()->getGrandTotal();
        $this->logger->info('Order Additional Information : ' . json_encode($additionalInformation));

        //$transactionId = $creditMemo->getTransactionId(); // Uncomment if using dynamic transaction ID
    //   $transactionId = 80601091047; // Hardcoded for demonstration

        $transactionId = $additionalInformation['transactionId'];
        $cardNumber = $additionalInformation['cardNumber'];
        $expirationDate = $additionalInformation['expirationDate'];

        if ($transactionId) {
            try {
                // Fetch transaction details
                $transactionDetails = $this->getTransactionDetails($transactionId);
                $this->logger->info('Transaction Details: ' . json_encode($transactionDetails));
//var_dump($transactionDetails);
//exit();

                // Check the transaction status
                $transactionStatus = $transactionDetails['transaction']['transactionStatus'];

                // Define statuses for refund and void requests
                $refundStatus = 'settledSuccessfully';
                $voidStatuses = ['authorizedPendingCapture', 'capturedPendingSettlement'];

                // Determine the action based on the transaction status
                if ($transactionStatus === $refundStatus) {
                    // Send refund transaction for 'settledSuccessfully'
                    $response = $this->createRefundTransaction($transactionId, $amount, $cardNumber, $expirationDate);
                    $this->logger->info('Refund Transaction Response: ' . json_encode($response));
                } elseif (in_array($transactionStatus, $voidStatuses)) {
                    // Send void transaction for 'authorizedPendingCapture' and 'capturedPendingSettlement'
                    $response = $this->createVoidTransaction($transactionId);
                    $this->logger->info('Void Transaction Response: ' . json_encode($response));
                } else {
                    // Handle other statuses if necessary
                    $this->logger->info('No action taken for transaction status: ' . $transactionStatus);
                }


            } catch (\Exception $e) {
                $this->logger->info('Error: ' . $e->getMessage());
            }
        } else {
            $this->logger->info('No transaction ID found.');
        }
    }
}
    private function createVoidTransaction($transactionId)
    {
        // Define the request payload
        $data = [
            "createTransactionRequest" => [
                "merchantAuthentication" => $this->merchantAuthentication,
                "refId" => "123456",
                "transactionRequest" => [
                    "transactionType" => "voidTransaction",
                    "refTransId" => $transactionId
                ]
            ]
        ];

        // Log the request data
        $this->logger->info('Void Transaction Request: ' . json_encode($data));

        // Send the API request
        return $this->sendApiRequest($data);
    }

    private function createRefundTransaction($transactionId, $amount, $cardNumber, $expirationDate )
    {
        // Define the refund request payload
        $data = [
            "createTransactionRequest" => [
                "merchantAuthentication" => $this->merchantAuthentication,
                "refId" => "123456",
                "transactionRequest" => [
                    "transactionType" => "refundTransaction",
                    "amount" => $amount,
                    "payment" => [
                        "creditCard" => [
                            "cardNumber" => $cardNumber,
                            "expirationDate" => $expirationDate
                        ]
                    ],
                    "refTransId" => $transactionId
                ]
            ]
        ];

        // Log the refund request data
        $this->logger->info('Refund Transaction Request: ' . json_encode($data));

        // Send the API request
        return $this->sendApiRequest($data);
    }

    private function getTransactionDetails($transactionId)
    {
        // Define the transaction details request payload
        $data = [
            "getTransactionDetailsRequest" => [
                "merchantAuthentication" => $this->merchantAuthentication,
                "transId" => $transactionId
            ]
        ];

        // Send the API request
        return $this->sendApiRequest($data);
    }

    private function sendApiRequest($data)
    {
        $apiUrl = "https://api.authorize.net/xml/v1/request.api";
        $options = [
            'http' => [
                'header'  => "Content-type: application/json\r\n",
                'method'  => 'POST',
                'content' => json_encode($data),
            ],
        ];

        $context  = stream_context_create($options);
        $response = file_get_contents($apiUrl, false, $context);

        if ($response === FALSE) {
            $this->logger->info('Error connecting to Authorize.net');
            throw new \Exception('Error connecting to Authorize.net');
        }

        $cleanResponse = preg_replace("/^" . pack('H*','EFBBBF') . "/", '', $response);
        $responseData = json_decode($cleanResponse, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            $this->logger->info('Error decoding JSON response: ' . json_last_error_msg());
            throw new \Exception('Error decoding JSON response: ' . json_last_error_msg());
        }

        return $responseData;
    }
}
