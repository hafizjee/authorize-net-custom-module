define(
    [
        'uiComponent',
        'Magento_Checkout/js/model/payment/renderer-list'
    ],
    function (
        Component,
        rendererList
    ) {
        'use strict';
        rendererList.push(
            {
                type: 'customauthorizenet',
                component: 'MS_OfflinePayment/js/view/payment/method-renderer/customauthorizenet-method'
            }
        );
        return Component.extend({});
    }
);