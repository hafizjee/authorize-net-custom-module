<?php
namespace MS\AuthorizeNet\Block\Adminhtml\Order\View;
class Custom extends \Magento\Sales\Block\Adminhtml\Order\View\Tab\Info
{

}
