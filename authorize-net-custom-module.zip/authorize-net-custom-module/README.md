# authorize-net-custom-module
This custom module integrates Authorize.net payment functionality into Magento, allowing for offline payments via credit card with a custom payment link in the order success email. It automates order status changes and email notifications post-payment.
