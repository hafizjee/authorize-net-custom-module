<?php

namespace MS\OfflinePayment\Observer;

use Magento\Framework\Event\ObserverInterface;


class Paymentmethoddisable implements ObserverInterface
{

    protected $_appState;
    public function __construct(
        \Magento\Framework\App\State $appState
    ) {
        $this->_appState = $appState;
    }
    /**
     * payment_method_is_active event handler.
     *
     * @param \Magento\Framework\Event\Observer $observer
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        // you can replace "customauthorizenet" with your required payment method code
        if($observer->getEvent()->getMethodInstance()->getCode()=="customauthorizenet"
            && in_array($this->_appState->getAreaCode(), $this->getDisableAreas())){
            $checkResult = $observer->getEvent()->getResult();
            $checkResult->setData('is_available', false); //this is disabling the payment method at checkout page
        }
    }

    protected function getDisableAreas(){

    return array( \Magento\Framework\App\Area::AREA_FRONTEND, \Magento\Framework\App\Area::AREA_WEBAPI_REST);
}

}
