<?php
namespace MS\AuthorizeNet\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer;
use Magento\Sales\Model\Order;
use Magento\Framework\App\Request\Http;
use Magento\Framework\Message\ManagerInterface;
use Psr\Log\LoggerInterface;

class OrderPlaceAfter implements ObserverInterface
{
    protected $request;
    protected $messageManager;
    protected $logger;

    public function __construct(
        Http $request,
        ManagerInterface $messageManager,
        LoggerInterface $logger
    ) {
        $this->request = $request;
        $this->messageManager = $messageManager;
        $this->logger = $logger;
    }

    public function execute(Observer $observer)
    {
        // Logger setup
        $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/custom_authorize_net.log');
        $logger = new \Zend_Log();
        $logger->addWriter($writer);

        try {
            $order = $observer->getEvent()->getOrder();
            $orderId = $order->getIncrementId();
            $amount = $order->getGrandTotal();
            $billingAddress = $order->getBillingAddress();
            $customerEmail = $order->getCustomerEmail();
            $paymentMethod = $order->getPayment()->getMethodInstance()->getCode();

            $logger->info('Order Place After Observer triggered for order ID: ' . $orderId);
            $logger->info('Order amount: ' . $amount);
            $logger->info('Customer email: ' . $customerEmail);
            $logger->info('Payment method: ' . $paymentMethod);

            // Check if the payment method is Custom AuthorizeNet
            if ($paymentMethod == 'customauthorizenet') {
                $order->setData('payment_method_can', true);
            }

            // Save the order to ensure the custom attribute is stored
            $order->save();

            // Log after saving the order
            $logger->info('Order saved with payment_method_can: ' . $order->getData('payment_method_can'));

        } catch (\Exception $e) {
            $logger->error('Authorize.net payment error: ' . $e->getMessage());
        }
    }
}
