<?php
namespace MS\AuthorizeNet\Controller\Index;

use Magento\Framework\App\Action\Action;

class Index extends Action
{
    public function execute()
    {
        echo "Controller call successfully";
    }
}
